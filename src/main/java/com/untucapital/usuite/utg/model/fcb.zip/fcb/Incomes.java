package com.untucapital.usuite.utg.model.fcb;

import com.untucapital.usuite.utg.model.AbstractEntity;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "incomes")
public class Incomes extends AbstractEntity {
}

