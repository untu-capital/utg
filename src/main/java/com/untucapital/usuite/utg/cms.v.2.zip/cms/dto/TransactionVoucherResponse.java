package com.untucapital.usuite.utg.cms.dto;

import com.untucapital.usuite.utg.cms.enums.ApprovalStatus;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * @author tjchidanika
 * @created 9/10/2023
 */

@Getter
@Setter
@Builder
public class TransactionVoucherResponse {

    private Integer id;

    private UserDTO initiator;
    private LocalDateTime applicationDate;

    private UserDTO firstApprover;
    private LocalDateTime firstApprovedAt;
    private ApprovalStatus firstApprovalStatus;

    private UserDTO secondApprover;
    private LocalDateTime secondApprovedAt;
    private ApprovalStatus secondApprovalStatus;

    private BigDecimal amount;
    private String amountInWords;
    private String withdrawalPurpose;
    private String currency;

    private Integer denomination100;
    private Integer denomination50;
    private Integer denomination20;
    private Integer denomination10;
    private Integer denomination5;
    private Integer denomination2;
    private Integer denomination1;
    private Integer denominationCents;

    private BranchDTO branch;
    private VaultDTO fromVault;
    private VaultDTO toVault;

}
