package com.untucapital.usuite.utg.cms.service;

import com.untucapital.usuite.utg.cms.dto.ApproverRequest;
import com.untucapital.usuite.utg.cms.dto.AuditTrailInitiatorRequest;
import com.untucapital.usuite.utg.cms.dto.ChangeAmountRequest;
import com.untucapital.usuite.utg.cms.model.AuditTrail;
import com.untucapital.usuite.utg.cms.repository.AuditTrailRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

/**
 * @author tjchidanika
 * @created 28/9/2023
 */

@Service
@RequiredArgsConstructor
public class AuditTrailService {
    private final AuditTrailRepository auditTrailRepository;

    //Get All
    public List<AuditTrail> getAllAuditTrails(){
        return auditTrailRepository.findAll();
    }
    //Get By Id
    public AuditTrail getAuditTrailById(Integer id){
        return auditTrailRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Audit Trail not found"));
    }
    //Add Initiator
    public AuditTrail addInitiator(AuditTrailInitiatorRequest request){
        AuditTrail auditTrail = AuditTrail.builder()
                .initiator(request.getInitiator())
                .amount(request.getAmount())
                .fromVault(request.getFromVault())
                .toVault(request.getToVault())
                .initiatedAt(LocalDateTime.now())
                .build();
        return auditTrailRepository.save(auditTrail);
    }

    //Add First Approver
    public AuditTrail addFirstApprover(ApproverRequest request){
        AuditTrail auditTrail = auditTrailRepository.findById(request.getId())
                .orElseThrow(() -> new RuntimeException("Audit Trail not found"));

//        auditTrail.setFirstApprover(request.getApprover());
        auditTrail.setFirstApprovedAt(LocalDateTime.now());
        return auditTrailRepository.save(auditTrail);
    }

    //Add Second Approver
    @Transactional
    public AuditTrail addSecondApprover(ApproverRequest request){

        AuditTrail auditTrail = auditTrailRepository.findById(request.getId())
                .orElseThrow(() -> new RuntimeException("Audit Trail not found"));

//        auditTrail.setSecondApprover(request.getApprover());
        auditTrail.setSecondApprovedAt(LocalDateTime.now());

        return auditTrailRepository.save(auditTrail);
    }

    //Delete Audit Trail
    public String deleteAuditTrail(Integer id){

        AuditTrail auditTrail = auditTrailRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Audit Trail not found"));

        auditTrailRepository.delete(auditTrail);
        return String.format("Audit Trail %d Deleted".formatted(id));
    }

    //Update Audit Trail
    @Transactional
    public AuditTrail updateAmount(ChangeAmountRequest request){
        AuditTrail auditTrail = auditTrailRepository.findById(request.getId())
                .orElseThrow(() -> new RuntimeException("Audit Trail not found"));

        if(auditTrail.getFirstApprover() == null){
            if (request.getAmount() != null && !request.getAmount().equals(auditTrail.getAmount())){
                auditTrail.setAmount(request.getAmount());
                return auditTrailRepository.save(auditTrail);
            }
        }
        else {
            throw new RuntimeException("Audit Trail has been approved");
        }

        return auditTrail;
    }
}
