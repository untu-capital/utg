package com.untucapital.usuite.utg.cms.enums;

/**
 * @author tjchidanika
 * @created 10/10/2023
 */

public enum ApprovalStatus {
    PENDING,
    APPROVED,
    REVISE,
}
