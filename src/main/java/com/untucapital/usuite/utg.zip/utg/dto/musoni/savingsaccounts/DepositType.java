package com.untucapital.usuite.utg.dto.musoni.savingsaccounts;

import lombok.Data;

@Data
public class DepositType {

    private int id;
    private String code;
    private String value;

}
