package com.untucapital.usuite.utg.dto.cms.req;

import lombok.Data;

@Data
public class VaultBalanceReq {

    private String accountName;
    private String accountNumber;
}
