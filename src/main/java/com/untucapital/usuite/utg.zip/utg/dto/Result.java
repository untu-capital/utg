package com.untucapital.usuite.utg.dto;

import lombok.Data;

@Data
public class Result {
    private String resultCode;
    private String resultMessage;
    private String resultDescription;
}
