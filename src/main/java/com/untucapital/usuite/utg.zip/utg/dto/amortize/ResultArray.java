package com.untucapital.usuite.utg.dto.amortize;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class ResultArray {

    private LoanObject loanObject;
}
