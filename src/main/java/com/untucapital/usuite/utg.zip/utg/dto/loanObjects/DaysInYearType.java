package com.untucapital.usuite.utg.dto.loanObjects;

public class DaysInYearType extends ModelAbstract {
}
