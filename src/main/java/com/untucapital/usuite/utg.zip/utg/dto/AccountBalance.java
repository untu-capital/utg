package com.untucapital.usuite.utg.dto;


import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class AccountBalance {

    private String account;
}
