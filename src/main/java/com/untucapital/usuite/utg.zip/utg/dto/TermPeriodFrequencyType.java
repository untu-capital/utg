package com.untucapital.usuite.utg.dto;

public class TermPeriodFrequencyType extends ModelAbstract {

}
