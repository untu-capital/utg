package com.untucapital.usuite.utg.dto.musoni.savingsaccounts;

import lombok.Data;

import java.util.List;

@Data
public class SavingsAccountLoans {

    private List<PageItems> pageItems;
}
