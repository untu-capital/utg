package com.untucapital.usuite.utg.repository;

import com.untucapital.usuite.utg.model.AppraisalLoanRequest;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppraisalLoanRequestRepository extends JpaRepository<AppraisalLoanRequest, Integer> {
}
