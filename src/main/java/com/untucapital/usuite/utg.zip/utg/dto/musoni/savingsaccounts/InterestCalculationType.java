package com.untucapital.usuite.utg.dto.musoni.savingsaccounts;

import lombok.Data;

@Data
public class InterestCalculationType {

    private int id;
    private String code;
    private String value;

}
