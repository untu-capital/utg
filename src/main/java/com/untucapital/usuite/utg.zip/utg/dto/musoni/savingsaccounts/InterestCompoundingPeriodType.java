package com.untucapital.usuite.utg.dto.musoni.savingsaccounts;

import lombok.Data;

@Data
public class InterestCompoundingPeriodType {

    private int id;
    private String code;
    private String value;
}
