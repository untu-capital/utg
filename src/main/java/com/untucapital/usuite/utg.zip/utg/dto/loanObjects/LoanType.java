package com.untucapital.usuite.utg.dto.loanObjects;

public class LoanType extends ModelAbstract {

}
