package com.untucapital.usuite.utg.dto.loanObjects;

public class InterestType extends ModelAbstract{

}
