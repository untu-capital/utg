package com.untucapital.usuite.utg.dto.musoni.savingsaccounts.enums;

public enum BranchType {

    HRE,
    BYO,
    GWR,
    GKW,
    HO
}
