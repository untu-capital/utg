package com.untucapital.usuite.utg.dto.loanObjects;

public class AmortizationType extends ModelAbstract {

}
