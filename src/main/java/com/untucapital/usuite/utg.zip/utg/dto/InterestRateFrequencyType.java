package com.untucapital.usuite.utg.dto;

public class InterestRateFrequencyType extends ModelAbstract {

}
