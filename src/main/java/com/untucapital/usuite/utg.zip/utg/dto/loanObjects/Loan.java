//package com.untucapital.usuite.utg.DTO.loanObjects;
//
//import lombok.*;
//
//import java.math.BigDecimal;
//
//@Builder
//@AllArgsConstructor
//@NoArgsConstructor
//@Getter
//@Setter
//public class Loan {
//
//    private Integer id;
//    private String accountNo;
//    private String externalId;
//    private Integer clientId;
//    private String clientAccountNo;
//    private String clientName;
//    private Integer clientOfficeId;
//    private Integer loanProductId;
//    private String loanProductName;
//    private String loanProductDescription;
//    private boolean isLoanProductLinkedToFloatingRate;
//    private Integer loanOfficerId;
//    private String loanOfficerName;
//    private BigDecimal principal;
//    private Integer approvedPrincipal;
//    private Integer proposedPrincipal;
//    private Integer termFrequency;
//    private Integer numberOfRepayments;
//    private Integer repaymentEvery;
//    private BigDecimal interestRatePerPeriod;
//    private Integer annualInterestRate;
//    private boolean isFloatingInterestRate;
//    private boolean allowPartialPeriodInterestCalcualtion;
//    private Integer transactionProcessingStrategyNameactionProcessingStrategyId;
//    private String transactionProcessingStrategyName;
//    private Integer[] expectedFirstRepaymentOnDate;
//    private Timeline timeline;
//    private String officeName;
//
//}
