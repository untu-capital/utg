package com.untucapital.usuite.utg.untu_capital.response;

public class GlobalImageResponse {

  private final String fileName;

  public GlobalImageResponse(String fileName) {
    this.fileName = fileName;
  }

  public String getFileName() {
    return fileName;
  }

}
