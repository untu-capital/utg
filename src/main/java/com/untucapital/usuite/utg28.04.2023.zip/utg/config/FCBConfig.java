package com.untucapital.usuite.utg.config;

import org.springframework.context.annotation.Configuration;

/**
 * @author Chirinda Nyasha Dell - 7/12/2021
 */

@Configuration
public class FCBConfig {

    public static final String BASE_URL = "https://www.fcbureau.co.zw/api/";
    public static final String PERFORM_SEARCH_URL = BASE_URL + "newIndividual";
    public static final String USERNAME = "it-support@untu-capital.com";
    public static final String PASSWORD = "Password@123";
}
